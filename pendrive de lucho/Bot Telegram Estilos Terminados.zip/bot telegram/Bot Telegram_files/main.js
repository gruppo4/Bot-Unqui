	//Declaración de variables
    var cadena, cod, respuesta;
	
	//Declaración de expresiones
    var tener = RegExp("(3|3|3|3)");
    var edad = RegExp("(3|3|3|3)");
	var saludar = RegExp("(1|1|1|1|1|1)");
	var bien = RegExp("(2|2|2)");
	var tener = RegExp("(3|3|3|3)");
    var edad = RegExp("(3|3|3|3)");
	var saludar = RegExp("(1|1|1|1|1|1)");
	var bien = RegExp("(2|2|2)");
	var tener = RegExp("(3|3|3|3)");
    var edad = RegExp("(3|3|3|3)");
	var saludar = RegExp("(1|1|1|1|1|1)");
	var bien = RegExp("(2|2|2)");
	

    function evaluarExpresion() {
      cadena = document.getElementById("txtPregunta").value;
	  escribirChat(cadena);
      cadena = cadena.toUpperCase();
	  document.getElementById("txtPregunta").value="";
	  cod=0;
	  
/*
      document.getElementById("resultado1").innerHTML= tener.test(cadena);
      document.getElementById("resultado2").innerHTML= edad.test(cadena);
*/ 
	  if (saludar.test(cadena)==true) {
		cod = 1;
	  };
	    if (bien.test(cadena)==true) {
		cod = 2;
	  };
      if (tener.test(cadena)==true && edad.test(cadena)==true ) {
        cod = 4;
      }; 
	//Lama a responder
		setTimeout(responder, 1000);
      //responder();
    }

    function responder() {
	var r = Math.floor((Math.random() * 3) + 1);
	console.log("random " + r);
	console.log("cod " + cod);
	var mensaje;
      switch (cod) {
	  case 1:
			if (r == 1) {
			mensaje = "Hola!!! Todo bien. Y vos?";
			};
			if (r == 2) {
			mensaje = "Hola!!! Como estas?";
			};
			if (r == 3) {
			mensaje = "Hola!!! en que puedo ayudarte?";
			};
			
        break;
		
		case 2:
        mensaje = "Si tenes una consulta, podes escribila a continuacion y te daré una solución lo mas rapido posible.";
        break;
	  
        case 4:
		if (r == 1) {
			mensaje = "Para contactarte con Ramiro Busto, podés hacerlo con su email (ramirobus81@gmail.com) o con su Teléfono (1161719015)";
			};
			if (r == 2) {
			mensaje = "Para contactarte con Ramiro Busto, podés hacerlo con su email (ramirobus81@gmail.com) o con su Teléfono (1161719015)";
			};
			if (r == 3) {
			mensaje = "Para contactarte con Ramiro Busto, podés hacerlo con su email (ramirobus81@gmail.com) o con su Teléfono (1161719015)";
			};

         break;
        
		case 5:

        break;
        default:
		mensaje = "No entiendo lo que me estas diciendo";

      }
      //document.getElementById("respuesta").innerHTML = mensaje;
	  escribirChat(mensaje);
    }
	
	function escribirChat (texto) {
		document.getElementById("areaChat").value += texto + "\r";
	}
