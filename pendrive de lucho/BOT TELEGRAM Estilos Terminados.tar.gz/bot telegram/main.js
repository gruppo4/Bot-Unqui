	//Declaración de variables
    var cadena, cod, respuesta;
	
	//Declaración de expresiones
    var a = RegExp("(1|1|1|1)");
    var b = RegExp("(2|2|2|2)");
	var c = RegExp("(3|3|3|3|3|3)");
	var d = RegExp("(4|4|4)");
	var e = RegExp("(5|5|5)");
	var f = RegExp("(6|6|6|6)");
    var g = RegExp("(7|7|7|7)");
	var h = RegExp("(8|8|8|8|8|8)");
	var i = RegExp("(9|9|9)");
	var j = RegExp("(10|10|10)");
	var k = RegExp("(11|11|11|11)");
    var l = RegExp("(12|12|12|12)");
	var m = RegExp("(13|13|13|13|13|13)");
	var n = RegExp("(14|14|14)");
	var o = RegExp("(15|15|15)");
	var p = RegExp("(16|16|16|16)");
    var q = RegExp("(17|17|17|17)");
	var r = RegExp("(18|18|18|18|18|18)");
	var s = RegExp("(19|19|19)");
	var t = RegExp("(20|20|20)");
    var a = RegExp("(1|1|1|1)");
    var b = RegExp("(2|2|2|2)");
	var c = RegExp("(3|3|3|3|3|3)");
	var d = RegExp("(4|4|4)");
	var e = RegExp("(5|5|5)");
	var f = RegExp("(6|6|6|6)");
    var g = RegExp("(7|7|7|7)");
	var h = RegExp("(8|8|8|8|8|8)");
	var i = RegExp("(9|9|9)");
	var j = RegExp("(10|10|10)");
	var k = RegExp("(11|11|11|11)");
    var l = RegExp("(12|12|12|12)");
	var m = RegExp("(13|13|13|13|13|13)");
	var n = RegExp("(14|14|14)");
	var o = RegExp("(15|15|15)");
	var p = RegExp("(16|16|16|16)");
    var q = RegExp("(17|17|17|17)");
	var r = RegExp("(18|18|18|18|18|18)");
	var s = RegExp("(19|19|19)");
	var t = RegExp("(20|20|20)");
    var a = RegExp("(1|1|1|1)");
    var b = RegExp("(2|2|2|2)");
	var c = RegExp("(3|3|3|3|3|3)");
	var d = RegExp("(4|4|4)");
	var e = RegExp("(5|5|5)");
	var f = RegExp("(6|6|6|6)");
    var g = RegExp("(7|7|7|7)");
	var h = RegExp("(8|8|8|8|8|8)");
	var i = RegExp("(9|9|9)");
	var j = RegExp("(10|10|10)");
	var k = RegExp("(11|11|11|11)");
    var l = RegExp("(12|12|12|12)");
	var m = RegExp("(13|13|13|13|13|13)");
	var n = RegExp("(14|14|14)");
	var o = RegExp("(15|15|15)");
	var p = RegExp("(16|16|16|16)");
    var q = RegExp("(17|17|17|17)");
	var r = RegExp("(18|18|18|18|18|18)");
	var s = RegExp("(19|19|19)");
	var t = RegExp("(20|20|20)");

	

    function evaluarExpresion() {
      cadena = document.getElementById("txtPregunta").value;
	  escribirChat(cadena);
      cadena = cadena.toUpperCase();
	  document.getElementById("txtPregunta").value="";
	  cod=0;
	  
/*
      document.getElementById("resultado1").innerHTML= tener.test(cadena);
      document.getElementById("resultado2").innerHTML= edad.test(cadena);
*/ 
	  if (a.test(cadena)==true) {
		cod = 1;
	  };
	    if (b.test(cadena)==true) {
		cod = 2;
	  };
	  if (c.test(cadena)==true) {
		cod = 3;
	  };
	  if (d.test(cadena)==true) {
		cod = 4;
	  };
	  if (e.test(cadena)==true) {
		cod = 5;
	  };
	  if (f.test(cadena)==true) {
		cod = 6;
	  };
	    if (g.test(cadena)==true) {
		cod = 7;
	  };
	  if (h.test(cadena)==true) {
		cod = 8;
	  };
	  if (i.test(cadena)==true) {
		cod = 9;
	  };
	  if (j.test(cadena)==true) {
		cod = 10;
	  };
	  if (k.test(cadena)==true) {
		cod = 11;
	  };
	    if (l.test(cadena)==true) {
		cod = 12;
	  };
	  if (m.test(cadena)==true) {
		cod = 13;
	  };
	  if (n.test(cadena)==true) {
		cod = 14;
	  };
	  if (o.test(cadena)==true) {
		cod = 15;
	  };
	  if (p.test(cadena)==true) {
		cod = 16;
	  };
	    if (q.test(cadena)==true) {
		cod = 17;
	  };
	  if (r.test(cadena)==true) {
		cod = 18;
	  };
	  if (s.test(cadena)==true) {
		cod = 19;
	  };
	  if (t.test(cadena)==true) {
		cod = 20;
	  };
	  	
	//Lama a responder
		setTimeout(responder, 400);
      //responder();
    }

    function responder() {
	var r = Math.floor((Math.random() * 3) + 1);
	console.log("random " + r);
	console.log("cod " + cod);
	var mensaje;
      switch (cod) {
	  case 1:
    	mensaje = "6) Departamento de Ingreso                                                             			7) Departamento de Titulos                                                             			8) Departamento de Alumnos"
		break;

	  	case 2:
        mensaje = "9) Cursos de Idioma                                                             				10) Diplomaturas                                                             						11) Administración"
        break;	  

		case 3:
        mensaje = "12) Tutores                                                             							13) Soporte Tecnico                                                           										14) Administración"
        break;

		case 4:
        mensaje = "15) Maestrias                                                           							16) Doctorados                                                             											17) Administracion"
        break;
		
		case 5:
        mensaje = "18) Tesoreria                                                             						19) RRHH                                                             											20) Contabilidad"
        break;

		case 6:
			mensaje = "Departamento de Ingreso" 
			break;

		case 7:
			mensaje =  "Departamento de Titulos"
			break;

		case 8:
			mensaje =  "Departamento de Alumnos"
			break;
	
		case 9:
			mensaje =  "Cursos de Idioma"
			break;

		case 10:
			mensaje =  "Diplomaturas"
			break;
	
		case 11:
			mensaje =  "Administración"
			break;
	
		case 12:
			mensaje =  "Tutores"
			break;
		
		case 13:
			mensaje =  "Soporte Tecnico"
			break;
				
		case 14:
			mensaje =  "Administración"
			break;
		
		case 15:
			mensaje =  "Maestrias"
			break;
		
		case 16:
			mensaje =  "Doctorados"
			break;
			
		case 17:
			mensaje =  "Administracion"
			break;

		case 18:
			mensaje =  "Tesoreria"
			break;
				
		case 19:
			mensaje =  "RRHH"
			break;
						
		case 20:
			mensaje =  "Contabilidad"
			break;
				
        default:
		mensaje = "1.  Información Academica. 				     2.  Información de extension. 				     3.  Información sobre carreras virtuales. 				     4.  Información de posgrado. 				     5.  Departamento Administrativo."
		break;
	}
      
      //document.getElementById("respuesta").innerHTML = mensaje;
	  escribirChat(mensaje);
    }
	
	function escribirChat (texto) {
		document.getElementById("areaChat").value = texto + "\r";
		document.getElementById("areaChat")
	}
